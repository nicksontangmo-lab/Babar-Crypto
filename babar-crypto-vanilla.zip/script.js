// Render Lucide icons (loaded via CDN as a global `lucide` object)
if (window.lucide) {
  lucide.createIcons();
}

// ---------------------------------------------------------------------
// Scroll-reveal: fade-up entrance the first time a section scrolls into view
// ---------------------------------------------------------------------
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

document.querySelectorAll('.reveal').forEach((el) => revealObserver.observe(el));

// ---------------------------------------------------------------------
// Curriculum: clicking a module row crossfades the matching illustration
// ---------------------------------------------------------------------
const moduleRows = document.querySelectorAll('.module-row');
const illustrations = document.querySelectorAll('.illustration');

function setActiveModule(index) {
  moduleRows.forEach((row) => {
    const isActive = row.dataset.index === String(index);
    row.classList.toggle('is-active', isActive);
    row.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });

  illustrations.forEach((illu) => {
    illu.classList.toggle('is-active', illu.dataset.index === String(index));
  });
}

moduleRows.forEach((row) => {
  row.addEventListener('click', () => setActiveModule(row.dataset.index));
});
